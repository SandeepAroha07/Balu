from setuptools import setup, find_packages
import time
import os

setup(name='o9dummygit',
      packages=['o9dummyfolder'],
      include_package_data=True
      )
